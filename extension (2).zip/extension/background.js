let mediaStream = null;
let audioContext = null;
let mediaRecorder = null;
let isCapturing = false;
let socket = null;

// Handle messages from content script or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'START_CAPTURE':
      startCapture(message.sourceLanguage, message.targetLanguage);
      break;
    case 'STOP_CAPTURE':
      stopCapture();
      break;
    case 'GET_STATUS':
      sendResponse({ isCapturing });
      break;
  }
  return true;
});

async function startCapture(sourceLanguage, targetLanguage) {
  if (isCapturing) return;

  try {
    // Get the active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Start tab audio capture
    const stream = await chrome.tabCapture.capture({
      audio: true,
      video: false
    });

    mediaStream = stream;
    
    // Initialize WebSocket connection to your existing backend
    socket = new WebSocket('ws://localhost:3000/translation');
    
    socket.onopen = () => {
      // Send initial configuration
      socket.send(JSON.stringify({
        type: 'config',
        sourceLanguage,
        targetLanguage,
        userId: localStorage.getItem('userId'), // Get user ID from extension storage
        meetingId: localStorage.getItem('meetingId') // Get meeting ID from extension storage
      }));
    };

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      // Forward transcripts to your web app through window.postMessage
      window.postMessage({
        type: 'MEETINGLINGO_TRANSCRIPT',
        data: data
      }, '*');
    };

    // Set up audio processing
    audioContext = new AudioContext();
    const source = audioContext.createMediaStreamSource(stream);
    
    // Create a processor node for audio analysis
    const processor = audioContext.createScriptProcessor(4096, 1, 1);
    
    processor.onaudioprocess = (e) => {
      if (!isCapturing) return;
      
      // Get audio data
      const inputData = e.inputBuffer.getChannelData(0);
      
      // Send audio data to backend via WebSocket
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({
          type: 'audio',
          data: Array.from(inputData)
        }));
      }
    };

    // Connect the audio nodes
    source.connect(processor);
    processor.connect(audioContext.destination);
    
    isCapturing = true;

    // Notify content script that capture has started
    chrome.tabs.sendMessage(tab.id, { type: 'CAPTURE_STARTED' });

  } catch (error) {
    console.error('Error starting capture:', error);
    stopCapture();
  }
}

function stopCapture() {
  if (!isCapturing) return;

  try {
    // Stop media stream
    if (mediaStream) {
      mediaStream.getTracks().forEach(track => track.stop());
      mediaStream = null;
    }

    // Close audio context
    if (audioContext) {
      audioContext.close();
      audioContext = null;
    }

    // Close WebSocket connection
    if (socket) {
      socket.close();
      socket = null;
    }

    isCapturing = false;

    // Notify content script that capture has stopped
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (tab) {
        chrome.tabs.sendMessage(tab.id, { type: 'CAPTURE_STOPPED' });
      }
    });

  } catch (error) {
    console.error('Error stopping capture:', error);
  }
} 