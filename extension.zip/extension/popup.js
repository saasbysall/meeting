document.addEventListener('DOMContentLoaded', async () => {
  const statusEl = document.getElementById('status');
  const sourceLanguageEl = document.getElementById('sourceLanguage');
  const targetLanguageEl = document.getElementById('targetLanguage');

  // Get current tab to check if we're in a meeting
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const isMeetingTab = tab.url.match(/(meet\.google\.com|zoom\.us|teams\.microsoft\.com)/);

  // Get stored language preferences
  const { sourceLanguage = 'en-US', targetLanguage = 'es-ES' } = await chrome.storage.local.get(['sourceLanguage', 'targetLanguage']);
  
  sourceLanguageEl.textContent = sourceLanguage;
  targetLanguageEl.textContent = targetLanguage;

  if (isMeetingTab) {
    // Check if we're currently translating in this tab
    const { isTranslating = false } = await chrome.storage.local.get(['isTranslating']);
    statusEl.textContent = isTranslating ? 'Translating' : 'Ready';
    statusEl.className = isTranslating ? 'active' : '';
  } else {
    statusEl.textContent = 'Not in meeting';
    statusEl.className = 'inactive';
  }

  // Let the webpage know the extension is installed
  chrome.tabs.sendMessage(tab.id, { type: 'MEETINGLINGO_EXTENSION_PRESENT' });
}); 