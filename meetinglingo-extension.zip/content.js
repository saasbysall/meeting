let translationContainer = null;
let isTranslating = false;

// Initialize the translation UI
function initializeUI() {
  // Create container for translation UI
  translationContainer = document.createElement('div');
  translationContainer.id = 'meetinglingo-container';
  translationContainer.innerHTML = `
    <div class="meetinglingo-panel">
      <div class="meetinglingo-header">
        <img src="${chrome.runtime.getURL('icons/icon48.png')}" alt="MeetingLingo" />
        <h3>MeetingLingo</h3>
        <button id="meetinglingo-toggle" class="meetinglingo-button">
          ${isTranslating ? 'Stop Translation' : 'Start Translation'}
        </button>
      </div>
      <div class="meetinglingo-content">
        <div class="meetinglingo-transcripts"></div>
      </div>
      <div class="meetinglingo-settings">
        <select id="meetinglingo-source-language">
          <option value="en-US">English</option>
          <option value="es-ES">Spanish</option>
          <option value="fr-FR">French</option>
          <!-- Add more languages as needed -->
        </select>
        <select id="meetinglingo-target-language">
          <option value="es-ES">Spanish</option>
          <option value="en-US">English</option>
          <option value="fr-FR">French</option>
          <!-- Add more languages as needed -->
        </select>
      </div>
    </div>
  `;

  // Add the container to the page
  document.body.appendChild(translationContainer);

  // Add event listeners
  const toggleButton = document.getElementById('meetinglingo-toggle');
  toggleButton.addEventListener('click', toggleTranslation);

  // Add language change listeners
  document.getElementById('meetinglingo-source-language').addEventListener('change', updateLanguages);
  document.getElementById('meetinglingo-target-language').addEventListener('change', updateLanguages);
}

// Toggle translation on/off
function toggleTranslation() {
  const toggleButton = document.getElementById('meetinglingo-toggle');
  const sourceLanguage = document.getElementById('meetinglingo-source-language').value;
  const targetLanguage = document.getElementById('meetinglingo-target-language').value;

  if (!isTranslating) {
    // Start translation
    chrome.runtime.sendMessage({
      type: 'START_CAPTURE',
      sourceLanguage,
      targetLanguage
    });
    toggleButton.textContent = 'Stop Translation';
    isTranslating = true;
  } else {
    // Stop translation
    chrome.runtime.sendMessage({ type: 'STOP_CAPTURE' });
    toggleButton.textContent = 'Start Translation';
    isTranslating = false;
  }
}

// Update languages when changed
function updateLanguages() {
  if (isTranslating) {
    // Restart translation with new languages
    toggleTranslation(); // Stop
    toggleTranslation(); // Start
  }
}

// Add a new transcript to the UI
function addTranscript(original, translated) {
  const transcriptsContainer = document.querySelector('.meetinglingo-transcripts');
  const transcriptElement = document.createElement('div');
  transcriptElement.className = 'meetinglingo-transcript';
  transcriptElement.innerHTML = `
    <div class="original">${original}</div>
    <div class="translated">${translated}</div>
  `;
  transcriptsContainer.appendChild(transcriptElement);
  transcriptsContainer.scrollTop = transcriptsContainer.scrollHeight;
}

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'CAPTURE_STARTED':
      console.log('Capture started');
      break;
    case 'CAPTURE_STOPPED':
      console.log('Capture stopped');
      break;
    case 'TRANSCRIPT':
      addTranscript(message.original, message.translated);
      break;
  }
});

// Initialize when the page is ready
if (document.readyState === 'complete') {
  initializeUI();
} else {
  window.addEventListener('load', initializeUI);
} 